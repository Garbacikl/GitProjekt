<?php

namespace App\Providers;

use App\Http\Enums\CzytelnicyRole;
use App\Models\Czytelnik;
use Dotenv\Util\Str;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot()
    {
        $this->defineUserRoleGate('isUser', CzytelnicyRole::USER);
        $this->defineUserRoleGate('isAdmin', CzytelnicyRole::ADMIN);
    }

    private function defineUserRoleGate($name, $role): void
    {
        Gate::define($name, function(Czytelnik $czytelnik) use ($role) {
            return $czytelnik->role == $role;
        });
    }
}
