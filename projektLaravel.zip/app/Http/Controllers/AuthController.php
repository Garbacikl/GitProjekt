<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use App\Models\Czytelnik;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Http\Request;

class AuthController extends Controller
{
    public function login()
    {
        if (Auth::check()) {
            return redirect()->route('index');
        }
        return view('login');
    }


public function authenticate(Request $request)
{
    $credentials = $request->validate([
        'login' => ['required', 'string'],
        'password' => ['required'],
    ]);
    //dd($credentials);
    $czytelnik = Czytelnik::where('login', $credentials['login'])->first();

    // if ($czytelnik && Hash::check($credentials['password'], $czytelnik->password))
    if(Auth::attempt($credentials))
    {
        $request->session()->regenerate();
        $request->session()->put('user_id', $czytelnik->id);

        return redirect()->route('index')->with('success', 'Logowanie zakończone pomyślnie!');
    }

    return redirect()->route('index')->with('error', 'Podane dane logowania są nieprawidłowe.');
}

public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect()->route('index')->with('success','Wylogowano pomyslnie');
    }
}
