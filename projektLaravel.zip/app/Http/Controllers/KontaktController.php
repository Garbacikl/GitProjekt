<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;

use Illuminate\Http\Request;

class KontaktController extends Controller
{
    public function kontakt()
    {
        return view('kontakt');
    }
}
