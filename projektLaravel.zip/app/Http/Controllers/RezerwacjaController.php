<?php

namespace App\Http\Controllers;
use App\Models\Ksiazka;
use App\Models\Czytelnik;
use App\Models\ZarezerwowaneKsiazki;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Spatie\LaravelIgnition\Recorders\DumpRecorder\Dump;

class RezerwacjaController extends Controller
{


    public function index()
{
    // Pobierz zalogowanego użytkownika
    $user = Auth::user();

    // Pobierz dane czytelnika z modelu Czytelnik
    $czytelnik = Czytelnik::where('id', $user->id)->first();

    // Pobierz wypożyczone książki dla zalogowanego użytkownika
    $borrowedBooks = $czytelnik->borrowedBooks()->with('book')->get();

    return view('rezerwacja', ['borrowedBooks' => $borrowedBooks]);
}


    public function search(Request $request)
    {
        $authorName = $request->input('author_name');
        $bookTitle = $request->input('book_title');

        $booksQuery = Ksiazka::query();

        if ($authorName) {
            $booksQuery->where('nazwa_autora', $authorName);
        }

        if ($bookTitle) {
            $booksQuery->where('tytul', 'like', "%$bookTitle%");
        }

        $books = $booksQuery->get();

        $user = Auth::user();

        // Pobierz dane czytelnika z modelu Czytelnik
        $czytelnik = Czytelnik::where('id', $user->id)->first();

        // Pobierz wypożyczone książki dla zalogowanego użytkownika
        $borrowedBooks = $czytelnik->borrowedBooks()->get();

        return view('rezerwacja', [
            'books' => $books,
            'borrowedBooks' => $borrowedBooks
        ]);
    }

    public function rezerwuj(Request $request){
        // Pobierz id zalogowanego użytkownika
        $userId = Auth::id();
        // Pobierz id książki z żądania
        $ksiazkaId = $request->input('id');
        $dataRezerwacji = $request->input('data_rezerwacji');
        $dataOddania = $request->input('data_oddania');

        $dzisiaj = date('Y-m-d');

        if (strtotime($dataRezerwacji) < strtotime($dzisiaj)) {
            return redirect()->route('rezerwacja')->with('fail', 'Data rezerwacji musi być większa lub równa dzisiejszej dacie.');
        }

        if (strtotime($dataRezerwacji) >= strtotime($dataOddania)) {
            return redirect()->route('rezerwacja')->with('fail', 'Data rezerwacji musi być wcześniejsza niż data oddania.');
        }

        if (!ZarezerwowaneKsiazki::isBookAvailable($ksiazkaId, $dataRezerwacji, $dataOddania)) {
            return redirect()->route('rezerwacja')->with('fail', 'Książka jest niedostępna.');
        }

        $borrowedBooksCount = ZarezerwowaneKsiazki::where('id_czytelnika', $userId)->count();

        // Jeśli użytkownik ma już 5 rekordów w tabeli WypozyczoneKsiazki, zwróć błąd
        if ($borrowedBooksCount >= 5) {
            return redirect()->route('rezerwacja')->with('fail', 'Osiagnieto limit wyposazonych ksiazek.');
        }

        // Stwórz nowy rekord w tabeli wypożyczonych książek
        $wypozyczenie = ZarezerwowaneKsiazki::create([
            'id_czytelnika' => $userId,
            'id_ksiazki' => $ksiazkaId,
            'data_rezerwacji' => $dataRezerwacji,
            'data_oddania' => $dataOddania,
        ]);
        return redirect()->route('rezerwacja')->with('success', 'Książka została wypożyczona.');
    }

    public function anulujRezerwacje($id)
{
    $rezerwacja = ZarezerwowaneKsiazki::find($id);
    if ($rezerwacja) {
        $rezerwacja->delete();
        return redirect()->back()->with('success', 'Rezerwacja została anulowana.');
    }
    return redirect()->back()->with('fail', 'Nie można znaleźć rezerwacji do anulowania.');
}

}
