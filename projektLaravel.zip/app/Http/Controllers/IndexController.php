<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;

use App\Models\Ksiazka;
use Illuminate\Http\Request;
use App\Models\Autor;

class IndexController extends Controller
{
    public function autors()
    {
        $books = Ksiazka::all();
        $autors = Autor::all();

        return view('index', ['books' => $books],['autors' => $autors]);
    }
}
