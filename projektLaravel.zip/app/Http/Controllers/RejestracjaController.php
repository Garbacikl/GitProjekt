<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Czytelnik;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class RejestracjaController extends Controller
{
    public function showForm()
{
    return view('rejestracja');
}


public function register(Request $request)
    {
        $validatedData = $request->validate([
            'login' => 'required|unique:czytelnicy,login',
            'password' => 'required|min:6',
            'confirmPassword' => 'required|same:password',
            'email' => 'required|email|unique:czytelnicy',
            'phone' => 'required',
            'street' => 'required',
            'city' => 'required',
            'zipCode' => 'required',
        ]);
        // dd($validatedData);
        $czytelnik = Czytelnik::create([
            'login' => $validatedData['login'],
            'password' => Hash::make($validatedData['password']),
            'email' => $validatedData['email'],
            'tel' => $validatedData['phone'],
            'street' => $validatedData['street'],
            'city' => $validatedData['city'],
            'zipCode' => $validatedData['zipCode'],
        ]);

        return redirect()->route('index')->with('success', 'Rejestracja zakończona pomyślnie!');
    }
}
