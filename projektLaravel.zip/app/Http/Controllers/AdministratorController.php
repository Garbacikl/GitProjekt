<?php

namespace App\Http\Controllers;

use App\Models\Autor;
use App\Models\Czytelnik;
use App\Models\Ksiazka;
use Illuminate\Support\Facades\Session;
use Illuminate\Http\Request;

class AdministratorController extends Controller
{
    public function index2()
    {
        return view('addBook');
    }

    public function addBook(Request $request)
{
    // Walidacja danych
    $validatedData = $request->validate([
        'book_title' => 'required',
        'author_name' => 'required',
    ]);

    // Sprawdzenie czy autor istnieje w tabeli 'autorzy' lub utworzenie nowego
    $autor = Autor::firstOrCreate(
        ['nazwa_autora' => $validatedData['author_name']]
    );


    // Utworzenie nowej książki
    $ksiazka = new Ksiazka();
    $ksiazka->tytul = $validatedData['book_title'];
    $ksiazka->nazwa_autora = $validatedData['author_name'];
    $ksiazka->id_autora = $autor->id;
    $ksiazka->status = 'Dostępna'; // Ustawienie domyślnego statusu wypożyczenia
    $ksiazka->save();

    Session::flash('success', 'Książka została dodana pomyślnie!');

    // Przekierowanie z wiadomością sukcesu
    return redirect()->route('index2')->with('success', 'Książka została dodana pomyślnie!');
}
public function searchBook(Request $request)
    {
        $authorName = $request->input('author_name');
        $bookTitle = $request->input('book_title');

        $booksQuery = Ksiazka::query();

        if ($authorName) {
            $booksQuery->where('nazwa_autora', $authorName);
        }

        if ($bookTitle) {
            $booksQuery->where('tytul', 'like', "%$bookTitle%");
        }

        $books = $booksQuery->get();




        return view('addBook', [
            'books' => $books,
        ]);
    }

    public function editBook(Request $request)
    {
        $id=$request->input('id');
        // Znalezienie książki po ID
        $book = Ksiazka::findOrFail($id);
        // Przekazanie książki do widoku edycji
        return view('editBook', ['book' => $book]);
    }
    public function showEditBookForm($id)
    {
        $book = Ksiazka::findOrFail($id);

        return view('addBook', [
            'book' => $book,
        ]);
    }

    public function updateBook(Request $request)
    {
        $id=$request->input('id');

        // Pobierz dane książki do aktualizacji
        $book = Ksiazka::findOrFail($id);

        // Zaktualizuj dane książki na podstawie danych z formularza
        $book->tytul = $request->input('title');
        $book->nazwa_autora = $request->input('author');

        // Zapisz zmiany
        $book->save();

        // Przekieruj użytkownika po aktualizacji książki
        return redirect()->route('addBook', ['id' => $id])->with('success', 'Książka została pomyślnie edytowana.');
    }

    public function editUserIndex()
    {
        return view('editUser');
    }

    public function searchUser(Request $request)
    {
        $userLogin = $request->input('login');
        $usersQuery = Czytelnik::query();

        if ($userLogin) {
            $usersQuery->where('login', $userLogin);
        }

        $users = $usersQuery->get();

        return view('editUser', [
            'users' => $users,
        ]);
    }

    public function showEditUserForm($id)
    {
        $user = Czytelnik::findOrFail($id);

        return view('editUser', [
            'user' => $user,
        ]);
    }

    public function updateUser(Request $request)
    {
        $id=$request->input('id');

        // Pobierz dane książki do aktualizacji
        $user = Czytelnik::findOrFail($id);

        // Zaktualizuj dane książki na podstawie danych z formularza
        $user->login = $request->input('login');
        $user->email = $request->input('email');
        $user->role = $request->input('role');
        $user->tel = $request->input('tel');
        $user->street = $request->input('street');
        $user->city = $request->input('city');
        $user->zipCode = $request->input('zip_code');


        // Zapisz zmiany
        $user->save();

        // Przekieruj użytkownika po aktualizacji książki
        return redirect()->route('editUser', ['id' => $id])->with('success', 'Czytelnik został pomyślnie zaktualizowany.');
    }

    public function deleteBook($id)
    {
        // Znajdź książkę o podanym ID
        $book = Ksiazka::findOrFail($id);

        // Usuń książkę
        $book->delete();

        // Przekieruj z wiadomością o sukcesie
        return redirect()->route('index2')->with('success', 'Książka została pomyślnie usunięta.');
    }

    public function deleteUser($id)
    {
        // Znajdź książkę o podanym ID
        $user = Czytelnik::findOrFail($id);

        // Usuń książkę
        $user->delete();

        // Przekieruj z wiadomością o sukcesie
        return redirect()->route('editUser')->with('success', 'Czytelnik został pomyślnie usunięty.');
    }
}
