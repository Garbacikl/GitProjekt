<?php

namespace App\Http\Controllers;
use App\Models\Ksiazka;
use Illuminate\Http\Request;
use App\Models\Autor;
use Illuminate\Support\Facades\Session;


class KsiazkiController extends Controller
{
    public function ksiazki()
{
    $books = Ksiazka::orderBy('nazwa_autora')->get()->groupBy('nazwa_autora');
    return view('ksiazki', ['books' => $books]);
}

}

