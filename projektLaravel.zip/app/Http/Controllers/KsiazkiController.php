<?php

namespace App\Http\Controllers;
use App\Models\Ksiazka;
use Illuminate\Http\Request;
use App\Models\Autor;

class KsiazkiController extends Controller
{
    public function ksiazki()
    {
        $books = Ksiazka::all();
        $autors = Autor::all();
        return view('index', ['books' => $books],['autors' => $autors]);
    }
}

