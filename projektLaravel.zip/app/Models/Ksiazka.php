<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ksiazka extends Model
{
    protected $table = 'ksiazki';
    use HasFactory;

    protected $fillable = ['tytul', 'nazwa_autora', 'status_wypozyczenia', 'data_wypozyczenia'];

    public function autor()
    {
        return $this->belongsTo(Autor::class, 'nazwa_autora', 'nazwa_autora');
    }
}
