<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Autor extends Model
{
    protected $table = 'autorzy';

    use HasFactory;

    protected $primaryKey = 'id';
    protected $fillable = ['nazwa_autora'];

    public function ksiazki()
    {
        return $this->hasMany(Ksiazka::class, 'nazwa_autora', 'nazwa_autora');
    }
}
