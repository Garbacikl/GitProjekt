<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Hash;
use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Auth\Authenticatable as AuthenticableTrait;

class Czytelnik extends Model implements Authenticatable{
    use AuthenticableTrait;

    protected $table = 'czytelnicy';

    protected $fillable = [
        'login',
        'password',
        'email',
        'tel',
        'street',
        'city',
        'zipCode',
    ];

    // Hashowanie hasła przed zapisaniem do bazy danych
    public function setPasswordAttribute($value)
    {
        $this->attributes['password'] = Hash::make($value);
    }

    public function getAuthIdentifierName()
    {
        return 'id'; // Zwracamy nazwę kolumny, która jest identyfikatorem użytkownika
    }

    public function getAuthIdentifier()
    {
        return $this->getKey(); // Zwracamy wartość identyfikatora użytkownika
    }

    public function getAuthPasswordName()
    {
        return 'password'; // Nazwa kolumny przechowującej hasło
    }

    public function getAuthPassword()
    {
        return $this->password; // Zwrócenie zahaszowanego hasła
    }

    public function getRememberToken()
    {
        return $this->remember_token; // Zwrócenie tokenu pamięci sesji
    }

    public function setRememberToken($value)
    {
        $this->remember_token = $value; // Ustawienie tokenu pamięci sesji
    }
}
