<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ZarezerwowaneKsiazki extends Model
{
    use HasFactory;

    protected $table = 'zarezerwowane_ksiazki';

    protected $fillable = [
        'id_czytelnika',
        'id_ksiazki',
        'data_rezerwacji',
        'data_oddania',
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'id_czytelnika');
    }


    // Relacja: Wypożyczona książka należy do książki
    public function book()
    {
        return $this->belongsTo(Ksiazka::class, 'id_ksiazki', 'id_ksiazki');
    }

    public static function isBookAvailable($ksiazkaId, $startDate, $endDate)
{
    // Konwertujemy daty na format Y-m-d, aby łatwo je porównać
    $startDate = date('Y-m-d', strtotime($startDate));
    $endDate = date('Y-m-d', strtotime($endDate));
    // Pobieramy wszystkie wypożyczenia dla danej książki, które kolidują z podanym przedziałem czasowym
    $wypozyczenia = ZarezerwowaneKsiazki::where('id_ksiazki', $ksiazkaId)
        ->where(function($query) use ($startDate, $endDate) {
            $query->whereBetween('data_rezerwacji', [$startDate, $endDate])
                  ->orWhereBetween('data_oddania', [$startDate, $endDate])
                  ->orWhere(function($query) use ($startDate, $endDate) {
                      $query->where('data_rezerwacji', '<=', $startDate)
                            ->where('data_oddania', '>=', $endDate);
                  });
        })
        ->get();

    // Jeśli istnieją takie wypożyczenia, to książka nie jest dostępna w podanym terminie
    return $wypozyczenia->isEmpty();
}


}

