<?php

use App\Http\Controllers\AdministratorController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\IndexController;
use App\Http\Controllers\InfoController;
use App\Http\Controllers\KontaktController;
use App\Http\Controllers\RejestracjaController;
use App\Http\Controllers\KsiazkiController;
use App\Http\Controllers\RezerwacjaController;

// use App\Http\Controllers\LoginController;

// Route::get('/', function () {
//     return view('welcome');
// });
Route::controller(IndexController::class)->group(function () {
Route::get('/',[IndexController::class, 'autors'])->name('index');
});


Route::get('/kontakt', [KontaktController::class, 'kontakt'])->name('kontakt');

    Route::controller(RejestracjaController::class)->group(function () {
        Route::middleware(['guest'])->group(function () {
            Route::get('/rejestracja', [RejestracjaController::class, 'showForm'])->name('rejestracja');
            Route::post('/rejestracja', [RejestracjaController::class, 'register'])->name('rejestracja.submit');
        });
    });

Route::get('/info', [InfoController::class, 'info'])->name('info');

Route::get('/ksiazki', [KsiazkiController::class, 'ksiazki'])->name('ksiazki');

Route::middleware(['auth'])->group(function () {
    Route::middleware(['can:isAdmin'])->group(function () {

        Route::get('/addBook', [AdministratorController::class, 'index2'])->name('index2');
        Route::post('/addBook/search', [AdministratorController::class, 'searchBook'])->name('booksSearchEdit');

        Route::post('/addBook', [AdministratorController::class, 'addBook'])->name('addBook');

        Route::put('/update-book', [AdministratorController::class, 'updateBook'])->name('updateBook');
        Route::get('/editBook{id}', [AdministratorController::class, 'showEditBookForm'])->name('editBookForm');
        Route::delete('/deleteBook/{id}', [AdministratorController::class,'deleteBook'])->name('deleteBook');


        Route::get('/editUser',[AdministratorController::class, 'editUserIndex'])->name('editUser');
        Route::post('/editUser/search', [AdministratorController::class, 'searchUser'])->name('user.search.edit');

        Route::get('/editUser/{id}', [AdministratorController::class, 'showEditUserForm'])->name('editUserForm');
        Route::put('/update-user', [AdministratorController::class, 'updateUser'])->name('updateUser');
        Route::delete('/deleteUser/{id}', [AdministratorController::class,'deleteUser'])->name('deleteUser');

    });
});

Route::middleware(['auth'])->group(function () {
    Route::get('/rezerwacja', [RezerwacjaController::class, 'index'])->name('rezerwacja');
    Route::post('/rezerwacja/search', [RezerwacjaController::class, 'search'])->name('books.search');
    Route::post('/rezerwacja', [RezerwacjaController::class, 'rezerwuj'])->name('zarezerwuj');
    Route::delete('/rezerwacja/{id}', [RezerwacjaController::class, 'anulujRezerwacje'])->name('anuluj_rezerwacje');
});

use App\Http\Controllers\AuthController;
Route::controller(AuthController::class)->group(function () {
Route::get('/login', [AuthController::class, 'login'])->name('login');
Route::post('/', [AuthController::class, 'authenticate'])->name('login.authenticate');
Route::get('/index', 'logout')->name('logout');
});


