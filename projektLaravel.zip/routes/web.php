<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\IndexController;
use App\Http\Controllers\InfoController;
use App\Http\Controllers\KontaktController;
use App\Http\Controllers\RejestracjaController;
use App\Http\Controllers\KsiazkiController;

// use App\Http\Controllers\LoginController;

// Route::get('/', function () {
//     return view('welcome');
// });
Route::controller(IndexController::class)->group(function () {
Route::get('/',[IndexController::class, 'autors'])->name('index');
});


Route::get('/kontakt', [KontaktController::class, 'kontakt'])->name('kontakt');

Route::controller(IndexController::class)->group(function () {
Route::get('/rejestracja', [RejestracjaController::class, 'showForm'])->name('rejestracja');
Route::post('/rejestracja', [RejestracjaController::class, 'register'])->name('rejestracja.submit');
});

Route::get('/info', [InfoController::class, 'info'])->name('info');

use App\Http\Controllers\AuthController;
Route::controller(AuthController::class)->group(function () {
Route::get('/login', [AuthController::class, 'login'])->name('login');
Route::post('/', [AuthController::class, 'authenticate'])->name('login.authenticate');
Route::get('/index', 'logout')->name('logout');

});
