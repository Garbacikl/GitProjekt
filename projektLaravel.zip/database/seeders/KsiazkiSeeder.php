<?php

namespace Database\Seeders;

use App\Models\Autor;
use App\Models\Ksiazka;
use Illuminate\Database\Seeder;

class KsiazkiSeeder extends Seeder
{
    public function run(): void
    {
        // Dodajemy pierwszą książkę
        $this->addBook('Wiedźmin', 'Andrzej Sapkowski');

        // Dodajemy drugą książkę
        $this->addBook('Harry Potter', 'J.K. Rowling');

        // Dodajemy trzecią książkę
        $this->addBook('Pan Tadeusz', 'Adam Mickiewicz');

        // Dodajemy czwartą książkę
        $this->addBook('Hobbit ', 'J.R.R. Tolkien');

        $this->addBook('Upadek Gondolinu ', 'J.R.R. Tolkien');

        $this->addBook('Rzeźbiarz Łez ', 'Erin Doom');

        $this->addBook('Przyjaciel   ', 'Agnes Sour');

        $this->addBook('Zapach ', 'Katarzyna Małecka');

        $this->addBook('Więcej niz współlokator ', 'Kenadll Ryan');


    }

    private function addBook(string $tytul, string $nazwa_autora): void
    {
        // Sprawdź, czy autor istnieje w tabeli Autorzy
        $autor = Autor::where('nazwa_autora', $nazwa_autora)->first();

        // Jeśli autor nie istnieje, dodaj go do tabeli Autorzy
        if (!$autor) {
            $autor = Autor::create([
                'nazwa_autora' => $nazwa_autora,
            ]);
        }

        // Dodaj nową książkę z nazwą autora
        Ksiazka::create([
            'tytul' => $tytul,
            'nazwa_autora' => $nazwa_autora,
            'status' => 'Dostepna', // Pusta data wypożyczenia
            'id_autora' => $autor->id, // Przypisz ID autora do książki
        ]);
    }
}

