<?php

namespace Database\Seeders;
use App\Models\Pracownik;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class PracownicySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //Dodajemy pierwszego pracownika
        Pracownik::create([
            'login'=>'grazyna123',
            'password'=>'password123',
        ]);
    }
}
