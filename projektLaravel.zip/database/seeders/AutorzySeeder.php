<?php

namespace Database\Seeders;
use App\Models\Autor; 
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class AutorzySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Autor::create([
            'nazwa_autora' => 'Andrzej Sapkowski',
        ]);
    }
}
