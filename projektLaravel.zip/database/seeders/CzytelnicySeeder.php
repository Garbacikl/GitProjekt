<?php

namespace Database\Seeders;


use App\Models\Czytelnik;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CzytelnicySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Czytelnik::create([
            'login'=>'lukasz',
            'password'=>'lukasz',
            'email'=>'lurkasz2@email.com',
            'role'=>'admin',
            'tel'=>'531462311',
            'street'=>'Długie 2A',
            'city'=>'Jedlicze',
            'zipCode'=>'38-460',
        ]);
        Czytelnik::create([
            'login'=>'lukasz1',
            'password'=>'lukasz1',
            'email'=>'lurkaszqw2@email.com',
            'tel'=>'531462311',
            'street'=>'Długie 2A',
            'city'=>'Jedlicze',
            'zipCode'=>'38-460',
        ]);
    }
}
