<?php

namespace Database\Seeders;


use App\Models\Czytelnik;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CzytelnicySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Czytelnik::create([
            'login'=>'lukasz',
            'password'=>'lukasz',
            'email'=>'lurkasz@email.com',
            'tel'=>'531462311',
            'street'=>'Długie 2A',
            'city'=>'Jedlicze',
            'zipCode'=>'38-460',
        ]);
    }
}
