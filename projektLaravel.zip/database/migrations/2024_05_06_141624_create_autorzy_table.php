<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAutorzyTable extends Migration
{
    public function up()
    {
        Schema::create('autorzy', function (Blueprint $table) {
            $table->id();
            $table->string('nazwa_autora');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('autorzy');
    }
}