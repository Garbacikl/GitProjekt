<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('wypozyczone_ksiazki', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('id_czytelnika');
            $table->foreign('id_czytelnika')->references('id')->on('czytelnicy')->onDelete('cascade');
            $table->unsignedBigInteger('id_ksiazki');
            $table->foreign('id_ksiazki')->references('id_ksiazki')->on('ksiazki')->onDelete('cascade');
            $table->date('data_wypozyczenia');
            $table->timestamps();
        });
        
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('wypozyczone_ksiazki');
    }
};
