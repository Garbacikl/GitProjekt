<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateKsiazkiTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ksiazki', function (Blueprint $table) {
            $table->id('id_ksiazki');
            $table->string('tytul');
            $table->string('nazwa_autora');
            $table->string('status_wypozyczenia')->default('Dostępna');
            $table->date('data_wypozyczenia')->nullable();
            $table->unsignedBigInteger('id_autora');
            $table->foreign('id_autora')->references('id')->on('autorzy');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ksiazki');
    }
}

