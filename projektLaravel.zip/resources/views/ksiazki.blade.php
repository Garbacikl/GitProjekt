<HTML>

    @include('shared.head', ['pageTitle' => 'Biblioteka | Lista książek'])

        @php
            $links = [];
            foreach (range('A', 'Z') as $letter) {
                $links[] = ['header' => $letter, 'href' => '#' . $letter];
            }
        @endphp

<body>

    @include('shared.navbar', ['links' => $links])


    <div class="container mt-4">

        @php
            $currentLetter = '';
        @endphp
        @foreach ($books as $author => $authorBooks)
            @php
                $firstLetter = strtoupper(substr($author, 0, 1));
            @endphp

            @if ($firstLetter !== $currentLetter)
                @if ($currentLetter !== '')
                    </ol></div>
                @endif
                <hr>
                <div class="mb-3">
                    <h2 id="{{ $firstLetter }}">{{ $firstLetter }}</h2>
                    <ol>
                    @php
                        $currentLetter = $firstLetter;
                    @endphp
            @endif

            <li>{{ $author }}
                <ul>
                    @foreach ($authorBooks as $book)
                        <li>{{ $book->tytul }}</li>
                    @endforeach
                </ul>
            </li>
        @endforeach
        @if ($currentLetter !== '')
            </ol></div>
        @endif
    </div>

   @include('shared.footer')


</body>
</HTML>
