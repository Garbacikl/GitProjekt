<HTML>
    <head>
        <link rel="icon" href="data:;base64,iVBORw0KGgo=">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>tt</title>
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="C:\Lab001\Lab001\Lab001_AI1_start\lab1\js\bootstrap.bundle.js"></script>
        <style>
            .nav-link{
                font-family: Georgia, serif;
                font-size: 18px;
            }
            footer{
                font-family: Georgia, serif;
            }
        </style>
    </head>
    <body>

    <nav class="navbar navbar-expand-lg" style="background-color: #E55938" id="start">
        <div class="container-fluid">   
        <a class="navbar-brand" href="{{ route('index') }}"><img src="{{ asset('images/logo.png') }}" alt="Biblioteka publiczna logo" style="height: 50px; margin-left: 80px;"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item ">
                        <a class="nav-link  text-white" href="#start">Start</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link  text-white" href="#historia">Historia</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link  text-white" href="#kluby">Kluby</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link text-white" href="#miejsca">Miejsca</a>
                    </li>
                </ul>
                <form class="d-flex" role="search">
                    <input class="form-control me-2" type="search" placeholder="..." aria-label="Search">
                    <button class="btn btn-light text-dark" type="submit">Szukaj</button>
                </form>
            </div>
        </div>
    </nav>
       
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-9 mx-auto" style="margin: 50px 0 50px 0;">
                <h1 class="text-center">O Nas</h1>
                <hr>
                <h5 id="historia">Historia</h5>
                <p>Historia biblioteki sięga głęboko w przeszłość. Pierwotnie był to skromny dom z dużym ogrodem, który należał do pasjonata książek, starego profesora Juliana Marzeniewicza. Po jego śmierci, w testamencie odkryto zaskakujące zapisy, które nakazywały przekształcenie domu w bibliotekę otwartą dla wszystkich mieszkańców miasteczka. Tak rozpoczęła się historia.
                
                <h5 id="kluby">Kluby</h5>
                </p><p>Obecnie biblioteka składa się z kilku niezwykłych pomieszczeń, z których każde oferuje coś wyjątkowego dla miłośników literatury:
                </p><p>"Miłośnicy planszówek":Organizowane są regularne spotkania oraz turnieje, podczas których gracze rywalizują ze sobą w różnorodnych grach. Można tu spotkać zarówno doświadczonych weteranów gier planszowych, jak i osoby dopiero zaczynające swoją przygodę z tą formą rozrywki. 
                </p><p>"Anonimowi Andersenowie": To miejsce dedykowane fanom baśni i opowieści dla dzieci. W tej części biblioteki regularnie odbywają się spotkania, podczas których czytane są bajki i baśnie, a uczestnicy mogą wspólnie dyskutować na ich temat.
                </p><p>"Językowi Protestanci": Jest to miejsce dla miłośników poezji i literatury pięknej. Często organizowane są tu wieczory poetyckie, podczas których można wysłuchać recytacji wierszy oraz dyskutować o ich interpretacji.

                <h5 id="miejsca">Miejsca</h5>
                </p><p>Komiksowy Zaułek, czyli miejsce w którym zgromadzone są komiksy różnych gatunków i stylów. To ulubione miejsce młodszych czytelników, którzy mogą tu zagłębić się w świat przygód swoich ulubionych bohaterów.
                </p><p>Kącik Poezji to przytulne miejsce, gdzie można usiąść wygodnie w fotelu i oddać się lekturze najpiękniejszych wierszy. To także przestrzeń, gdzie można samemu tworzyć swoje wiersze, korzystając z dostępnych materiałów.
                </p><p>Grota Przygód:Specjalne pomieszczenie, które przypomina prawdziwą grotołaznię. W środku znajdują się regały z książkami przygodowymi, których bohaterowie zabierają czytelników w niezwykłe podróże po fantastycznych krainach.

                </p><p>Nasza biblioteka to nie tylko miejsce, gdzie można znaleźć książki do czytania, ale przede wszystkim wspólnota ludzi, którzy dzielą swoją miłość do literatury i kultury. To miejsce, które otwiera drzwi do wyobraźni i spełnia marzenia o przygodach, poezji i odkrywaniu nowych światów.
            </div>
        </div>
    </div>
     
    <footer class="text-white py-4" style="background-color: #E55938">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <h5>Numer telefonu:</h5>
                    <p>+48 123 456 789</p>
                </div>
                <div class="col-md-3">
                    <h5>E-mail:</h5>
                    <p>biblioteka@email.com</p>
                </div>
                <div class="col-md-3">
                    <h5>Adres:</h5>
                    <p>Ul. Ulica 123, 00-000 Miasto</p>
                </div>
                <div class="col-md-3">
                    <h5>Godziny otwarcia:</h5>
                    <p>Poniedziałek-Piątek: 9:00-18:00</p>
                    <p>Sobota-Niedziela: Zamknięte</p>
                </div>
            </div>
        </div>
    </footer>
</body>
</HTML>
