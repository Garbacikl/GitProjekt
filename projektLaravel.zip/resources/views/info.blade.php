<HTML>
    @include('shared.head', ['pageTitle' => 'Biblioteka | Informacje ogólne'])

    <body>
        @include('shared.navbar', [
            'links' => [
                'first' => ['header' => 'Start', 'href' => '#start'],
                'second' => ['header' => 'Historia', 'href' => '#historia'],
                'third' => ['header' => 'Kluby', 'href' => '#kluby'],
                'fourth' => ['header' => 'Miejsca', 'href' => '#miejsca']
            ]
        ])

    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-9 mx-auto" style="margin: 50px 0 50px 0;">
                <h1 class="text-center">O Nas</h1>
                <hr>
                <h5 id="historia">Historia</h5>
                <p>Historia biblioteki sięga głęboko w przeszłość. Pierwotnie był to skromny dom z dużym ogrodem, który należał do pasjonata książek, starego profesora Juliana Marzeniewicza. Po jego śmierci, w testamencie odkryto zaskakujące zapisy, które nakazywały przekształcenie domu w bibliotekę otwartą dla wszystkich mieszkańców miasteczka. Tak rozpoczęła się historia.

                <h5 id="kluby">Kluby</h5>
                </p><p>Obecnie biblioteka składa się z kilku niezwykłych pomieszczeń, z których każde oferuje coś wyjątkowego dla miłośników literatury:
                </p><p>"Miłośnicy planszówek":Organizowane są regularne spotkania oraz turnieje, podczas których gracze rywalizują ze sobą w różnorodnych grach. Można tu spotkać zarówno doświadczonych weteranów gier planszowych, jak i osoby dopiero zaczynające swoją przygodę z tą formą rozrywki.
                </p><p>"Anonimowi Andersenowie": To miejsce dedykowane fanom baśni i opowieści dla dzieci. W tej części biblioteki regularnie odbywają się spotkania, podczas których czytane są bajki i baśnie, a uczestnicy mogą wspólnie dyskutować na ich temat.
                </p><p>"Językowi Protestanci": Jest to miejsce dla miłośników poezji i literatury pięknej. Często organizowane są tu wieczory poetyckie, podczas których można wysłuchać recytacji wierszy oraz dyskutować o ich interpretacji.

                <h5 id="miejsca">Miejsca</h5>
                </p><p>Komiksowy Zaułek, czyli miejsce w którym zgromadzone są komiksy różnych gatunków i stylów. To ulubione miejsce młodszych czytelników, którzy mogą tu zagłębić się w świat przygód swoich ulubionych bohaterów.
                </p><p>Kącik Poezji to przytulne miejsce, gdzie można usiąść wygodnie w fotelu i oddać się lekturze najpiękniejszych wierszy. To także przestrzeń, gdzie można samemu tworzyć swoje wiersze, korzystając z dostępnych materiałów.
                </p><p>Grota Przygód:Specjalne pomieszczenie, które przypomina prawdziwą grotołaznię. W środku znajdują się regały z książkami przygodowymi, których bohaterowie zabierają czytelników w niezwykłe podróże po fantastycznych krainach.

                </p><p>Nasza biblioteka to nie tylko miejsce, gdzie można znaleźć książki do czytania, ale przede wszystkim wspólnota ludzi, którzy dzielą swoją miłość do literatury i kultury. To miejsce, które otwiera drzwi do wyobraźni i spełnia marzenia o przygodach, poezji i odkrywaniu nowych światów.
            </div>
        </div>
    </div>

    @include('shared.footer')

</body>
</HTML>
