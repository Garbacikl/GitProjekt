<HTML>
    @include('shared.head', ['pageTitle' => 'Biblioteka | Rejestracja'])
    <body>

    @include('shared.navbar',[
        'links' => [
            'first' => ['header' => 'O Nas', 'href' => route('info')],
            'second' => ['header' => 'Lista ksiazek', 'href' => route('ksiazki')],
            'third' => ['header' => 'Kontakt', 'href' => route('kontakt')],
        ]
    ])

    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-9 mx-auto" style="margin: 50px 0 50px 0;">
                <h1 class="text-center" id="start">Formularz rejestracyjny</h1>
                <hr>
                <form method="POST" action="{{ route('rejestracja.submit') }}">
                @csrf
                    <div class="form-group">
                        <label for="login">Login:</label>
                        <input type="text" class="form-control" id="login" name="login" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Hasło:</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <div class="form-group">
                        <label for="confirmPassword">Powtórz hasło:</label>
                        <input type="password" class="form-control" id="confirmPassword" name="confirmPassword" required>
                    </div>
                    <div class="form-group">
                        <label for="email">E-mail:</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="phone">Telefon:</label>
                        <input type="tel" class="form-control" id="phone" name="phone" required>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-8">
                            <label for="street">Ulica i numer:</label>
                            <input type="text" class="form-control" id="street" name="street" required>
                        </div>
                    </div>
                    <div class="form-row" id="adres">
                        <div class="form-group col-md-8">
                            <label for="city">Miasto:</label>
                            <input type="text" class="form-control" id="city" name="city" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="zipCode">Kod pocztowy:</label>
                            <input type="text" class="form-control" id="zipCode" name="zipCode" required>
                        </div>
                    </div>
                    <button id="przycisk" type="submit" class="btn btn-primary btn-block">Zarejestruj się</button>
                </form>

            </div>
        </div>
    </div>

    @include('shared.footer')





</body>
</HTML>
