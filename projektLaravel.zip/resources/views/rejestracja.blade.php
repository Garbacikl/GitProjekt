<HTML>
    <head>
        <link rel="icon" href="data:;base64,iVBORw0KGgo=">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Tytul</title>
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="C:\Lab001\Lab001\Lab001_AI1_start\lab1\css\bootstrap.css">
        <script src="C:\Lab001\Lab001\Lab001_AI1_start\lab1\js\bootstrap.bundle.js"></script>
        <style>
            .nav-link{
                font-family: Georgia, serif;
                font-size: 18px;
            }
            footer{
                font-family: Georgia, serif;
            }
        </style>
    </head>
    <body>

    <nav class="navbar navbar-expand-lg" style="background-color: #E55938" id="start">
        <div class="container-fluid">
        <a class="navbar-brand" href="{{ route('index') }}"><img src="{{ asset('images/logo.png') }}" alt="Biblioteka publiczna logo" style="height: 50px; margin-left: 80px;"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item ">
                        <a class="nav-link  text-white" href="#start">Start</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link  text-white" href="#nazwa">Historia</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link  text-white" href="#linki">Przydatne linki</a>
                    </li>
                </ul>
                <form class="d-flex" role="search">
                    <input class="form-control me-2" type="search" placeholder="..." aria-label="Search">
                    <button class="btn btn-light text-dark" type="submit">Szukaj</button>
                </form>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-9 mx-auto" style="margin: 50px 0 50px 0;">
                <h1 class="text-center">Formularz rejestracyjny</h1>
                <hr>
                <form method="POST" action="{{ route('rejestracja.submit') }}">
                @csrf
                    <div class="form-group">
                        <label for="login">Login:</label>
                        <input type="text" class="form-control" id="login" name="login" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Hasło:</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <div class="form-group">
                        <label for="confirmPassword">Powtórz hasło:</label>
                        <input type="password" class="form-control" id="confirmPassword" name="confirmPassword" required>
                    </div>
                    <div class="form-group">
                        <label for="email">E-mail:</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="phone">Telefon:</label>
                        <input type="tel" class="form-control" id="phone" name="phone" required>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-8">
                            <label for="street">Ulica i numer:</label>
                            <input type="text" class="form-control" id="street" name="street" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-8">
                            <label for="city">Miasto:</label>
                            <input type="text" class="form-control" id="city" name="city" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="zipCode">Kod pocztowy:</label>
                            <input type="text" class="form-control" id="zipCode" name="zipCode" required>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Zarejestruj się</button>
                </form>

            </div>
        </div>
    </div>

    @include('shared.footer')





</body>
</HTML>
