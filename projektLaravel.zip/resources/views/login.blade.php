<HTML>
    <head>
        <link rel="icon" href="data:;base64,iVBORw0KGgo=">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>asfs</title>
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <style>
            .nav-link{
                font-family: Georgia, serif;
                font-size: 18px;
            }
            footer{
                font-family: Georgia, serif;
            }
        </style>
    </head>
    <body>
<div style="margin: 50px 10%;">
    <h2 class="text-center">Zaloguj</h2>


    <form method="POST" action="{{ route('login.authenticate') }}">
        @csrf
        <div class="form-group">
            <label for="login">Login</label>
            <input type="text" class="form-control" id="login" name="login" placeholder="Wprowadź login">
        </div>
        <div class="form-group">
            <label for="password">Hasło</label>
            <input type="password" class="form-control" id="password" name="password" placeholder="Wprowadź hasło">
        </div>
        <button type="submit" class="btn btn-primary d-block mx-auto">Zaloguj się</button>
    </form>

</div>

</body>
</HTML>
