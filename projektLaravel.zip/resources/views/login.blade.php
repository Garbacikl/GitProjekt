<HTML>
    @include('shared.head', ['pageTitle' => 'Biblioteka | Informacje ogólne'])

    <body>
        @include('shared.navbar', [
            'links' => []
        ])

        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-7 mx-auto" style="margin: 50px 0 77px 0;">
                    <h2 class="text-center">Zaloguj</h2>

                    <form method="POST" action="{{ route('login.authenticate') }}">
                        @csrf
                        <div class="form-group">
                            <label for="login">Login</label>
                            <input type="text" class="form-control" id="login" name="login" placeholder="Wprowadź login">
                        </div>
                        <div class="form-group">
                            <label for="password">Hasło</label>
                            <input type="password" class="form-control" id="password" name="password" placeholder="Wprowadź hasło">
                        </div>
                        <button type="submit" class="btn btn-primary d-block mx-auto">Zaloguj się</button>
                    </form>

                    <form action="{{ route('rejestracja') }}">
                        <div class="text-center mt-4">
                            <label for="form">Nie masz konta? Załóż je teraz.</label>
                        </div>
                        <button type="submit" class="btn btn-primary d-block mx-auto">Formularz rejestracyjny</button>
                    </form>
                </div>

                </div>
            </div>

        @include('shared.footer')

    </body>
</HTML>
