<HTML>
    <head>
        <link rel="icon" href="data:;base64,iVBORw0KGgo=">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>asfs</title>
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <style>
            .nav-link{
                font-family: Georgia, serif;
                font-size: 18px;
            }
            footer{
                font-family: Georgia, serif;
            }
        </style>
    </head>
    <body>

        @include('shared.navbar')
    <div class="container">
        <div class="row align-items-start">
            <div class="col-9" style="margin-top: 50px;">
                <div style="margin: 50px 10%;">

                    <hr>

                    <div class="row" style="justify-content: center;">
                        <div class="col-2">
                            <div style="margin:0 2%; display: flex; flex-direction: column; align-items: center; border: solid #E55938 2px;" onclick="window.location.href = '{{ route('info') }}';">
                                <img src="{{ asset('images/info.png') }}" alt="" style="width: 80%; margin-top: 5%;">
                                <a style="margin-top: 5px; font-size: small; text-align: center; width: 100%; overflow: hidden;">INFORMACJE</a>
                                <a style="font-size: small; text-align: center; width: 100%; overflow: hidden;">OGÓLNE</a>
                            </div>
                        </div>

                        <div class="col-2">
                            <div style="margin:0 2%; display: flex; flex-direction: column; align-items: center;border: solid #E55938 2px;" onclick="window.location.href = '{{ route('rejestracja') }}';">
                                <img src="{{ asset('images/register.png') }}" alt="" style="width: 80%;margin-top: 5%;">
                                <a style="margin-top: 5px; font-size: small;text-align: center; width: 100%; overflow: hidden;">STWÓRZ</a>
                                <a style="font-size: small;text-align: center; width: 100%; overflow: hidden;">UŻYTKOWNIKA</a>
                            </div>
                        </div>

                        <div class="col-2">
                            <div style="margin:0 2%; display: flex; flex-direction: column; align-items: center;border: solid #E55938 2px;" onclick="window.location.href = 'https://www.legimi.pl/biblioteki_podkarpackie/';">
                                <img src="{{ asset('images/legimi.png') }}" alt="" style="width: 80%;margin-top: 5%;">
                                <a style="margin-top: 5px; font-size: small;text-align: center; width: 100%; overflow: hidden;">LEGIMI</a>
                                <a style="font-size: small;text-align: center; width: 100%; overflow: hidden;">E-BOOK</a>
                            </div>
                        </div>

                        <div class="col-2">
                            <div style="margin:0 2%; display: flex; flex-direction: column; align-items: center;border: solid #E55938 2px;" onclick="window.location.href = '{{ route('rejestracja') }}';">
                                <img src="{{ asset('images/ksiazki.png') }}" alt="" style="width: 80%;margin-top: 5%;">
                                <a style="margin-top: 5px; font-size: small;text-align: center; width: 100%; overflow: hidden;">ZAREZERWUJ</a>
                                <a style="font-size: small;text-align: center; width: 100%; overflow: hidden;">KSIĄŻKE</a>
                            </div>
                        </div>

                        <div class="col-2" >
                            <div style="margin:0 2%; display: flex; flex-direction: column; align-items: center;border: solid #E55938 2px;" onclick="window.location.href = '{{ route('kontakt') }}';">
                                <img src="{{ asset('images/kontakt.png') }}" alt="" style="width: 80%;margin-top: 5%;">
                                <a style="margin-top: 5px; font-size: small;text-align: center; width: 100%; overflow: hidden;">NASZ</a>
                                <a style="font-size: small;text-align: center; width: 100%; overflow: hidden;">KONTAKT</a>
                            </div>
                        </div>

                    </div>

                    <hr>

                    <div id="myCarousel" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img src="{{ asset('images/karuzela2.jpg') }}" class="d-block w-100" alt="...">
                                <div class="carousel-caption" style=" border-radius: 10px;">
                                    <h5 style="text-shadow: 0 0 6px black;">KLUB KSIĄŻKI "ANONIMOWI ANDERSENOWIE"</h5>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <img src="{{ asset('images/karuzela3.jpg') }}" class="d-block w-100" alt="...">
                                <div class="carousel-caption" style=" border-radius: 10px;">
                                    <h5 style="text-shadow: 0 0 6px black;">KĄCIK DLA KAŻDEGO</h5>
                                </div>
                            </div>
                            <div class="carousel-item">
                            <img src="{{ asset('images/karuzela1.jpg') }}" class="d-block w-100" alt="...">
                                <div class="carousel-caption" style=" border-radius: 10px;">
                                    <h5 style="text-shadow: 0 0 6px black;">MIŁA OBSŁUGA</h5>
                                </div>
                            </div>
                        </div>
                        <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>

                    <hr>

                    <div class="container" id="aktualnosci">

                        <h2 class="text-center mb-4">Aktualności</h2>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="card mb-4">
                                    <div class="row g-0">
                                        <div class="col-md-4">
                                            <img src="{{ asset('images/news1.jpg') }}" class="img-fluid rounded-start" alt="..." style="height: 200px;">
                                        </div>
                                        <div class="col-md-8">
                                            <div class="card-body" style="height: 200px;">
                                                <h5 class="card-title"><a href="bookedday" class="text-decoration-none text-dark">Dzień książki</a></h5>
                                                <p class="card-text">Początki Dnia Książki sięgają starożytności, kiedy to księgi były uważane za skarby niezwykłej wartości. Dzisiaj, w erze internetu i nowoczesnych technologii, książka wciąż pozostaje niezastąpionym źródłem wiedzy, rozrywki i inspiracji</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="card mb-4">
                                    <div class="row g-0">
                                        <div class="col-md-4">
                                            <img src="{{ asset('images/news2.jpg') }}" class="img-fluid rounded-start" alt="..." style="height: 200px; width: 200px;">
                                        </div>
                                        <div class="col-md-8">
                                            <div class="card-body" style="height: 200px;">
                                                <h5 class="card-title"><a href="backtoskul" class="text-decoration-none text-dark">Powrót do szkoły</a></h5>
                                                <p class="card-text">Dla uczniów, powrót do szkoły to czas spotkań z przyjaciółmi, nauki nowych rzeczy i rozwijania swoich zainteresowań. To również czas, kiedy mogą ponownie zanurzyć się w atmosferze nauki i zdobywać nowe umiejętności. </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="card mb-4">
                                    <div class="row g-0">
                                        <div class="col-md-4">
                                            <img src="{{ asset('images/news3.jpg') }}" class="img-fluid rounded-start" alt="..." style="height: 200px; width: 200px;">
                                        </div>
                                        <div class="col-md-8">
                                            <div class="card-body" style="height: 200px;">
                                                <h5 class="card-title"><a href="new3" class="text-decoration-none text-dark">Wieczorek poezji</a></h5>
                                                <p class="card-text">Piątkowy wieczór jest wyjątkowy. Otwórz okno duszy i zaproś do niej odrobinę spokoju. Zanurz się w świecie literatury i poezji. To czas, który pozwala nam oderwać się od codzienności i zapomnieć o troskach.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <hr>

                    <div class="container" id="legimi">
                        <h2 class="text-center mb-4">O Legimi</h2>
                        <p>
                            Legimi to platforma cyfrowego czytania, która umożliwia dostęp do szerokiej gamy e-booków i audiobooków. Jest to popularna usługa subskrypcyjna, która oferuje użytkownikom możliwość czytania i słuchania książek na różnych urządzeniach, takich jak smartfony, tablety czy czytniki e-booków.
                        </p>
                        <ul>
                            <strong>Główne cechy Legimi obejmują:</strong>
                            <li>Duża biblioteka: Legimi oferuje dostęp do ogromnej kolekcji e-booków i audiobooków, obejmujących różnorodne gatunki literatury, w tym beletrystykę, literaturę faktu, poradniki, książki dla dzieci i młodzieży oraz wiele innych.</li>
                            <li>Subskrypcja: Użytkownicy Legimi mogą korzystać z usługi na zasadzie subskrypcji, co oznacza, że płacą miesięczną opłatę za dostęp do całej biblioteki książek.</li>
                            <li>Dostęp offline: Legimi umożliwia pobieranie e-booków i audiobooków, co pozwala użytkownikom czytać i słuchać książek nawet bez dostępu do internetu.</li>
                            <li>Personalizacja: Platforma oferuje funkcje personalizacji, takie jak zakładki, możliwość oznaczania ulubionych książek, tworzenie list odczytanych książek itp.</li>
                            <li>Współpraca z autorami i wydawcami: Legimi współpracuje z autorami i wydawcami, aby zapewnić dostęp do najnowszych i najbardziej pożądanych tytułów.</li>
                        </ul>
                        <p>
                            Legimi cieszy się dużą popularnością wśród osób, które preferują czytanie i słuchanie książek w formie cyfrowej oraz poszukują wygodnego sposobu dostępu do różnorodnej literatury.
                        </p>

                    </div>

                </div>
            </div>

            <div class="col-3" style="margin-top:50px">
                <div style="margin: 50px 10%;">
                    <hr>
                    @if(Auth::check())

                    <h2 class="text-center">Witaj {{ Auth::user()->login }}</h2>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <p>{{ Auth::user()->email }}</p>
                    </div>
                    <div class="form-group">
                        <label for="tel">Telefon:</label>
                        <p>{{ Auth::user()->tel }}</p>
                    </div>
                    <div class="form-group">
                        <label for="adres">Adres:</label>
                        <p>{{ Auth::user()->street }}, {{ Auth::user()->city }} {{ Auth::user()->zipCode }}</p>
                    </div>
                    <a class="btn btn-primary d-block mx-auto" href="{{ route('logout') }}">Wyloguj</a>


                    @else

                        <h2 class="text-center">Zaloguj</h2>

                        <form method="POST" action="{{ route('login.authenticate') }}">
                            @csrf
                            <div class="form-group">
                                <label for="login">Login</label>
                                <input type="text" class="form-control" id="login" name="login" placeholder="Wprowadź login">
                            </div>
                            <div class="form-group">
                                <label for="password">Hasło</label>
                                <input type="password" class="form-control" id="password" name="password" placeholder="Wprowadź hasło">
                            </div>
                            <button type="submit" class="btn btn-primary d-block mx-auto">Zaloguj się</button>
                        </form>

                    @endif

                </div>

                <div style="margin: 50px 10%; text-align: center;">
                    <hr>

                    <h2>Lista autorów</h2>
                    <table style="text-align: center;width:100%">
                        <thead style="border: 1px solid black;">
                            <tr>
                                <th >Id</th>
                                <th >Autor</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($autors as $autor)
                            <tr>
                                <td >{{ $autor->id }}</td>
                                <td >{{ $autor->nazwa_autora }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

   @include('shared.footer')


</body>
</HTML>
