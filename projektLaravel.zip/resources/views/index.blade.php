<HTML>



    @include('shared.head', ['pageTitle' => 'Biblioteka | Strona główna'])

    <body>

        @include('shared.navbar', [
            'links' => [
                'first' => ['header' => 'Start', 'href' => '#start'],
                'second' => ['header' => 'Karuzela', 'href' => '#myCarousel'],
                'third' => ['header' => 'Aktualnosci', 'href' => '#aktualnosci'],
                'fourth' => ['header' => 'Legimi', 'href' => '#legimi']
            ]
        ])


    <div class="container flex-grow-1">
        <div class="row align-items-start">
            <div class="col-9" style="margin-top: 50px;">
                <div style="margin: 50px 10%;">
                    @if(Session::has('success'))
                        <div id="successMessage" class="alert alert-success mt-3" role="alert">
                            {{ Session::get('success') }}
                        </div>
                    @elseif(Session::has('error'))
                        <div id="errorMessage" class="alert alert-danger mt-3" role="alert">
                            {{ Session::get('error') }}
                        </div>
                    @endif
                    <hr>



                    <div class="row justify-content-center">

                        @can('isAdmin')

                        <div class="col-6 col-sm-4 col-md-3 col-lg-2 mb-4">
                            <div class="d-flex flex-column align-items-center border border-warning" style="cursor: pointer;" onclick="window.location.href = '{{ route('editUser') }}';">
                                <img src="{{ asset('images/edytuj.png') }}" alt="" class="img-fluid mt-3" style="width: 80%;">
                                <a class="mt-2 text-center w-100 small text-reset text-decoration-none">EDYTUJ</a>
                                <a class="text-center w-100 small text-reset text-decoration-none">CZYTELNIKA</a>
                            </div>
                        </div>

                        @else

                        <div class="col-6 col-sm-4 col-md-3 col-lg-2 mb-4">
                            <div class="d-flex flex-column align-items-center border border-warning" style="cursor: pointer;" onclick="window.location.href = '{{ route('info') }}';">
                                <img src="{{ asset('images/info.png') }}" alt="" class="img-fluid mt-3" style="width: 80%;">
                                <a class="mt-2 text-center w-100 small text-reset text-decoration-none">INFORMACJE</a>
                                <a class="text-center w-100 small text-reset text-decoration-none">OGÓLNE</a>
                            </div>
                        </div>

                        @endcan

                        @if(Auth::check())

                        <div class="col-6 col-sm-4 col-md-3 col-lg-2 mb-4">
                            <div class="d-flex flex-column align-items-center border border-warning" onclick="window.location.href = '{{ route('rezerwacja') }}';">
                                <img src="{{ asset('images/rezerwuj.png') }}" alt="" class="img-fluid mt-3" style="width: 80%;">
                                <a class="mt-2 text-center w-100 small text-reset text-decoration-none">ZAREZERWUJ</a>
                                <a class="text-center w-100 small text-reset text-decoration-none">KSIĄŻKE</a>
                            </div>
                        </div>
                        @else

                        <div class="col-6 col-sm-4 col-md-3 col-lg-2 mb-4">
                            <div class="d-flex flex-column align-items-center border border-warning" onclick="window.location.href = '{{ route('rejestracja') }}';">
                                <img src="{{ asset('images/register.png') }}" alt="" class="img-fluid mt-3" style="width: 80%;">
                                <a class="mt-2 text-center w-100 small text-reset text-decoration-none">STWÓRZ</a>
                                <a class="text-center w-100 small text-reset text-decoration-none">UŻYTKOWNIKA</a>
                            </div>
                        </div>
                        @endif

                        @can('isAdmin')

                        <div class="col-6 col-sm-4 col-md-3 col-lg-2 mb-4">
                            <div class="d-flex flex-column align-items-center border border-warning" onclick="window.location.href = '{{ route('addBook') }}';">
                                <img src="{{ asset('images/dodaj.png') }}" alt="" class="img-fluid mt-3" style="width: 80%;">
                                <a class="mt-2 text-center w-100 small text-reset text-decoration-none">DODAJ</a>
                                <a class="text-center w-100 small text-reset text-decoration-none">KSIĄŻKE</a>
                            </div>
                        </div>

                        @else
                        <div class="col-6 col-sm-4 col-md-3 col-lg-2 mb-4">
                            <div class="d-flex flex-column align-items-center border border-warning" onclick="window.location.href = 'https://www.legimi.pl/biblioteki_podkarpackie/';">
                                <img src="{{ asset('images/legimi.png') }}" alt="" class="img-fluid mt-3" style="width: 80%;">
                                <a class="mt-2 text-center w-100 small text-reset text-decoration-none">LEGIMI</a>
                                <a class="text-center w-100 small text-reset text-decoration-none">E-BOOK</a>
                            </div>
                        </div>
                        @endcan

                        <div class="col-6 col-sm-4 col-md-3 col-lg-2 mb-4">
                            <div class="d-flex flex-column align-items-center border border-warning" onclick="window.location.href = '{{ route('ksiazki') }}';">
                                <img src="{{ asset('images/ksiazki.png') }}" alt="" class="img-fluid mt-3" style="width: 80%;">
                                <a class="mt-2 text-center w-100 small text-reset text-decoration-none">LISTA</a>
                                <a class="text-center w-100 small text-reset text-decoration-none">KSIĄŻEK</a>
                            </div>
                        </div>

                        <div class="col-6 col-sm-4 col-md-3 col-lg-2 mb-4">
                            <div class="d-flex flex-column align-items-center border border-warning" onclick="window.location.href = '{{ route('kontakt') }}';">
                                <img src="{{ asset('images/kontakt.png') }}" alt="" class="img-fluid mt-3" style="width: 80%;">
                                <a class="mt-2 text-center w-100 small text-reset text-decoration-none">NASZ</a>
                                <a class="text-center w-100 small text-reset text-decoration-none">KONTAKT</a>
                            </div>
                        </div>
                    </div>


                    <hr>

                    <div id="myCarousel" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img src="{{ asset('images/karuzela2.jpg') }}" class="d-block w-100" alt="...">
                                <div class="carousel-caption" style=" border-radius: 10px;">
                                    <h5 style="text-shadow: 0 0 6px black;">KLUB KSIĄŻKI "ANONIMOWI ANDERSENOWIE"</h5>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <img src="{{ asset('images/karuzela3.jpg') }}" class="d-block w-100" alt="...">
                                <div class="carousel-caption" style=" border-radius: 10px;">
                                    <h5 style="text-shadow: 0 0 6px black;">KĄCIK DLA KAŻDEGO</h5>
                                </div>
                            </div>
                            <div class="carousel-item">
                            <img src="{{ asset('images/karuzela1.jpg') }}" class="d-block w-100" alt="...">
                                <div class="carousel-caption" style=" border-radius: 10px;">
                                    <h5 style="text-shadow: 0 0 6px black;">MIŁA OBSŁUGA</h5>
                                </div>
                            </div>
                        </div>
                        <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>

                    <hr>

                    <div class="container mt-5" id="aktualnosci">
                        <h2 class="text-center mb-4">Aktualności</h2>

                        <div class="row">
                            <div class="col-12 mb-4">
                                <div class="card">
                                    <div class="row g-0">
                                        <div class="col-12 col-md-4">
                                            <img src="{{ asset('images/news1.jpg') }}" class="img-fluid rounded-start w-100" alt="..." style="height: 100%;">
                                        </div>
                                        <div class="col-12 col-md-8">
                                            <div class="card-body">
                                                <h5 class="card-title"><a href="bookedday" class="text-decoration-none text-dark">Dzień książki</a></h5>
                                                <p class="card-text">Początki Dnia Książki sięgają starożytności, kiedy to księgi były uważane za skarby niezwykłej wartości. Dzisiaj, w erze internetu i nowoczesnych technologii, książka wciąż pozostaje niezastąpionym źródłem wiedzy, rozrywki i inspiracji.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12 mb-4">
                                <div class="card">
                                    <div class="row g-0">
                                        <div class="col-12 col-md-4">
                                            <img src="{{ asset('images/news2.jpg') }}" class="img-fluid rounded-start w-100" alt="..." style="height: 100%;">
                                        </div>
                                        <div class="col-12 col-md-8">
                                            <div class="card-body">
                                                <h5 class="card-title"><a href="backtoskul" class="text-decoration-none text-dark">Powrót do szkoły</a></h5>
                                                <p class="card-text">Dla uczniów, powrót do szkoły to czas spotkań z przyjaciółmi, nauki nowych rzeczy i rozwijania swoich zainteresowań. To również czas, kiedy mogą ponownie zanurzyć się w atmosferze nauki i zdobywać nowe umiejętności.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12 mb-4">
                                <div class="card">
                                    <div class="row g-0">
                                        <div class="col-12 col-md-4">
                                            <img src="{{ asset('images/news3.jpg') }}" class="img-fluid rounded-start w-100" alt="..." style="height: 100%;">
                                        </div>
                                        <div class="col-12 col-md-8">
                                            <div class="card-body">
                                                <h5 class="card-title"><a href="new3" class="text-decoration-none text-dark">Wieczorek poezji</a></h5>
                                                <p class="card-text">Piątkowy wieczór jest wyjątkowy. Otwórz okno duszy i zaproś do niej odrobinę spokoju. Zanurz się w świecie literatury i poezji. To czas, który pozwala nam oderwać się od codzienności i zapomnieć o troskach.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <hr>

                    <div class="container mt-5" id="legimi">
                        <h2 class="text-center mb-4">O Legimi</h2>
                        <p>
                            Legimi to platforma cyfrowego czytania, która umożliwia dostęp do szerokiej gamy e-booków i audiobooków. Jest to popularna usługa subskrypcyjna, która oferuje użytkownikom możliwość czytania i słuchania książek na różnych urządzeniach, takich jak smartfony, tablety czy czytniki e-booków.
                        </p>
                        <ul>
                            <strong>Główne cechy Legimi obejmują:</strong>
                            <li>Duża biblioteka: Legimi oferuje dostęp do ogromnej kolekcji e-booków i audiobooków, obejmujących różnorodne gatunki literatury, w tym beletrystykę, literaturę faktu, poradniki, książki dla dzieci i młodzieży oraz wiele innych.</li>
                            <li>Subskrypcja: Użytkownicy Legimi mogą korzystać z usługi na zasadzie subskrypcji, co oznacza, że płacą miesięczną opłatę za dostęp do całej biblioteki książek.</li>
                            <li>Dostęp offline: Legimi umożliwia pobieranie e-booków i audiobooków, co pozwala użytkownikom czytać i słuchać książek nawet bez dostępu do internetu.</li>
                            <li>Personalizacja: Platforma oferuje funkcje personalizacji, takie jak zakładki, możliwość oznaczania ulubionych książek, tworzenie list odczytanych książek itp.</li>
                            <li>Współpraca z autorami i wydawcami: Legimi współpracuje z autorami i wydawcami, aby zapewnić dostęp do najnowszych i najbardziej pożądanych tytułów.</li>
                        </ul>
                        <p>
                            Legimi cieszy się dużą popularnością wśród osób, które preferują czytanie i słuchanie książek w formie cyfrowej oraz poszukują wygodnego sposobu dostępu do różnorodnej literatury.
                        </p>
                    </div>


                </div>
            </div>

            <div class="col-3" style="margin-top:50px">
                <div style="margin: 50px 10%;">
                    <hr>

                    @if(Auth::check())

                    <h2 class="text-center">Witaj {{ Auth::user()->login }}</h2>
                    <div class="form-group">
                        <p><strong>Email:</strong></p>
                        <p>{{ Auth::user()->email }}</p>
                    </div>
                    <div class="form-group">
                        <p>Telefon:</strong></p>
                        <p>{{ Auth::user()->tel }}</p>
                    </div>
                    <div class="form-group">
                        <p><strong>Adres:</strong></p>
                        <p>{{ Auth::user()->street }}, {{ Auth::user()->city }} {{ Auth::user()->zipCode }}</p>
                    </div>
                    <a class="btn btn-primary d-block mx-auto" href="{{ route('logout') }}">Wyloguj</a>


                    @else

                        <h2 class="text-center">Zaloguj</h2>

                        <form method="POST" action="{{ route('login.authenticate') }}">
                            @csrf
                            <div class="form-group">
                                <label for="login">Login</label>
                                <input type="text" class="form-control" id="login" name="login" placeholder="Wprowadź login">
                            </div>
                            <div class="form-group">
                                <label for="password">Hasło</label>
                                <input type="password" class="form-control" id="password" name="password" placeholder="Wprowadź hasło">
                            </div>
                            <button type="submit" class="btn btn-primary d-block mx-auto">Zaloguj się</button>
                        </form>

                    @endif

                </div>

                <div style="margin: 50px 10%; text-align: center;">
                    <hr>

                    <h2>Lista autorów</h2>
                    <table style="text-align: center;width:100%">
                        <thead style="border: 1px solid black;">
                            <tr>
                                <th >Id</th>
                                <th >Autor</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($autors as $autor)
                            <tr>
                                <td >{{ $autor->id }}</td>
                                <td >{{ $autor->nazwa_autora }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

   @include('shared.footer')


</body>
</HTML>
