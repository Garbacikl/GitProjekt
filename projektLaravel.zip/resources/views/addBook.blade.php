<HTML>
    @can('isAdmin')


    @include('shared.head', ['pageTitle' => 'Biblioteka | Informacje ogólne'])



    <body>
        @include('shared.navbar', [
            'links' => [
                'first' => ['header' => 'Start', 'href' => '#start'],
                'second' => ['header' => 'Historia', 'href' => '#historia'],
                'third' => ['header' => 'Kluby', 'href' => '#kluby'],
                'fourth' => ['header' => 'Miejsca', 'href' => '#miejsca']
            ]
        ])

    @if(Session::has('success'))
    <div id="successMessage" class="d-none alert alert-success mt-3" role="alert">
        {{ Session::get('success') }}
    </div>
    @endif

    <div class="container mt-5">
        <hr>
        <div class="row">
            <div class="col-md-12">
                <h2 class="text-center">Dodaj Książkę</h2>
            </div>
        </div>
        <div class="container">
            <div class="row mt-4">
                <div class="col-md-6">
                    <h5 class="text-center">Nazwa autora</h5>
                    <form action="{{ route('addBook') }}" method="POST">
                        @csrf
                        <div class="input-group mb-3">
                            <input type="text" name="author_name" class="form-control" placeholder="Wpisz imię i nazwisko autora">
                        </div>
                </div>
                <div class="col-md-6">
                    <h5 class="text-center">Tytuł</h5>
                    <div class="input-group mb-3">
                        <input type="text" name="book_title" class="form-control" placeholder="Wpisz tytuł książki">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col text-center">
                    <button class="btn btn-primary" type="submit">Dodaj</button>
                </div>
            </div>
            </form>
        </div>

        <hr>

        <div class="row">
            <div class="col-md-12">
                <h2 class="text-center">Edytuj Książkę</h2>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-md-6">
                <h5 class="text-center">Wyszukaj po Autorze</h5>
                <form action="{{ route('booksSearchEdit') }}" method="POST">
                    @csrf
                    <div class="input-group mb-3">
                        <input type="text" name="author_name" class="form-control" placeholder="Wpisz imię i nazwisko autora">
                        <button class="btn btn-primary" type="submit">Szukaj</button>
                    </div>
                </form>
            </div>
            <div class="col-md-6">
                <h5 class="text-center">Wyszukaj po Tytule</h5>
                <form action="{{ route('booksSearchEdit') }}" method="POST">
                    @csrf
                    <div class="input-group mb-3">
                        <input type="text" name="book_title" class="form-control" placeholder="Wpisz tytuł książki">
                        <button class="btn btn-primary" type="submit">Szukaj</button>
                    </div>
                </form>
            </div>
        </div>
    </div>



    <div class="container mt-5">
        @if (isset($books))
        <h2>Wyniki wyszukiwania</h2>
        <ul class="list-group" style="margin:0 0 50px ">
            <li class="list-group-item">
                <div class="row">
                    <div class="col-md-1">
                        <strong>ID</strong>
                    </div>
                    <div class="col-md-3">
                        <strong>Tytul</strong>
                    </div>
                    <div class="col-md-4    ">
                        <strong>Autor</strong>
                    </div>
                    <div class="col-md-3">
                        <strong>Data wypozyczenia</strong>
                    </div>
                    <div class="col-md-1">
                        <strong>Edycja</strong>
                    </div>

                </div>
            </li>
            @foreach ($books as $book)
            <li class="list-group-item">
                <div class="row">
                    <div class="col-md-1">
                        {{ $book->id_ksiazki }}
                    </div>
                    <div class="col-md-3">
                        {{ $book->tytul }}
                    </div>
                    <div class="col-md-4">
                        {{ $book->nazwa_autora }}
                    </div>
                    <div class="col-md-3">
                        {{ $book->data_wypozyczenia }}
                    </div>
                    <div class="col-md-1">
                        <a href="{{ route('editBookForm', ['id' => $book->id_ksiazki]) }}" class="btn btn-secondary">Edytuj</a>
                    </div>
                </div>
            </li>

                @endforeach
            </ul>
        @endif

        <hr>

        @if(@isset($book))

            <h2>Aktualne dane książki</h2>
            <p><strong>Tytul:</strong> {{ $book->tytul }}</p>
            <p><strong>Autor:</strong> {{ $book->nazwa_autora }}</p>
            <p><strong>Status wypożyczenia</strong>{{$book->status_wypozyczenia}}</p>

            <hr>

            <h2>Nowe dane ksiązki</h2>
            <form method="POST" action="{{ route('updateBook')}}">
                @csrf
                @method('PUT')
                <input type="hidden" name="id" value="{{ $book->id_ksiazki }}">
                <div class="form-group">
                    <label for="title">Nowy tytuł:</label>
                    <input type="text" class="form-control" id="title" name="title" value="{{ $book->tytul }}">
                </div>

                <div class="form-group">
                    <label for="author">Nowy autor:</label>
                    <input type="text" class="form-control" id="author" name="author" value="{{ $book->nazwa_autora }}">
                </div>

                <button type="submit" class="btn btn-primary">Zapisz zmiany</button>
            </form>
            <form method="POST" action="{{ route('deleteBook', ['id' => $book->id_ksiazki]) }}">
                @csrf
                @method('DELETE')
                <button type="submit" class="btn btn-danger">Usuń książkę</button>
            </form>
            <hr>
        @endif

    </div>

    @include('shared.footer')

</body>
@endcan
</HTML>
