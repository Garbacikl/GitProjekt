<footer class="text-white py-4" style="background-color: #E55938">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <h5>Numer telefonu:</h5>
                <p>+48 123 456 789</p>
            </div>
            <div class="col-md-3">
                <h5>E-mail:</h5>
                <p>biblioteka@email.com</p>
            </div>
            <div class="col-md-3">
                <h5>Adres:</h5>
                <p>Ul. Ulica 123, 00-000 Miasto</p>
            </div>
            <div class="col-md-3">
                <h5>Godziny otwarcia:</h5>
                <p>Poniedziałek-Piątek: 9:00-18:00</p>
                <p>Sobota-Niedziela: Zamknięte</p>
            </div>
        </div>
    </div>
</footer>
