<head>
    <link rel="icon" href="data:;base64,iVBORw0KGgo=">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ $pageTitle }}</title>
    <link rel="icon" href="{{ asset('images/icon.png') }}" type="image/png">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        .nav-link{
            font-family: Georgia, serif;
            font-size: 18px;
        }
        footer{
            font-family: Georgia, serif;
        }

    </style>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Pobranie elementu div, który ma się pojawić po dodaniu lub edycji książki
        var successMessageDiv = document.getElementById('successMessage');
        var errorMessageDiv = document.getElementById('errorMessage');

        // Sprawdzenie, czy komunikat sukcesu istnieje
        if (successMessageDiv) {
            // Ustawienie klasy, która spowoduje pojawienie się diva
            successMessageDiv.classList.remove('d-none');

            // Ukrycie diva po 5 sekundach
            setTimeout(function () {
                successMessageDiv.classList.add('d-none');
            }, 5000);
        }

        // Sprawdzenie, czy komunikat błędu istnieje
        if (errorMessageDiv) {
            // Ustawienie klasy, która spowoduje pojawienie się diva
            errorMessageDiv.classList.remove('d-none');

            // Ukrycie diva po 5 sekundach
            setTimeout(function () {
                errorMessageDiv.classList.add('d-none');
            }, 5000);
        }
    });
</script>
</head>
