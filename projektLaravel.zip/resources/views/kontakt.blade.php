<HTML>
    <head>
        <link rel="icon" href="data:;base64,iVBORw0KGgo=">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Title</title>
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="C:\Lab001\Lab001\Lab001_AI1_start\lab1\css\bootstrap.css">
        <script src="C:\Lab001\Lab001\Lab001_AI1_start\lab1\js\bootstrap.bundle.js"></script>
        <style>
            .nav-link{
                font-family: Georgia, serif;
                font-size: 18px;
            }
            footer{
                font-family: Georgia, serif;
            }
        </style>
    </head>
    <body>

        <nav class="navbar navbar-expand-lg" style="background-color: #E55938" id="start">
            <div class="container-fluid">   
            <a class="navbar-brand" href="{{ route('index') }}"><img src="{{ asset('images/logo.png') }}" alt="Biblioteka publiczna logo" style="height: 50px; margin-left: 80px;"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item ">
                        <a class="nav-link  text-white" href="#start">Start</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link  text-white" href="#myCarousel">Karuzela</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link  text-white" href="#aktualnosci">Aktualnosci</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link text-white" href="#legimi">Legimi</a>
                    </li>
                </ul>
                <form class="d-flex" role="search">
                    <input class="form-control me-2" type="search" placeholder="..." aria-label="Search">
                    <button class="btn btn-light text-dark" type="submit">Szukaj</button>
                </form>
            </div>
        </div>
    </nav>
          
    
             
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-9 mx-auto" style="margin: 50px 0 50px 0;">
                <h1 class="text-center">Kontakt</h1>

                <hr>

                <h5 id="nazwa">Biblioteka nazwa im. Łukasza Garbacika w Miasto</h5>
                <p>Ul. Ulica 123</p><p>
                    00-000 Miasto</p><p>
                    Tel.: (+48) 123 456 789</p><p>
                    e-mail: biblioteka@email.pl</p><p>
                    e-mail Inspektora Ochrony Danych:  inspektorDanych@email.pl</p>

                <hr>

                <h5 id="linki">Przydatne linki</h5>
                <p>Gmina Miasta <a href="">www.miasto.pl</a></p>
                <p>Gminny Ośrodek Pomocy Społecznej w Miescie: <a href="">gops.miasto.pl</a></p>
                <p>Samodzielny Publiczny Gminny Zespół Opieki Zdrowotnej w Miasto: <a href="">www.zozmiasto.pl</a></p>
                <p>Parafia Miasto <a href="">parafiamiasto.pl</a></p>
            </div>
        </div>
    </div>
     
    <footer class="text-white py-4" style="background-color: #E55938">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <h5>Numer telefonu:</h5>
                    <p>+48 123 456 789</p>
                </div>
                <div class="col-md-3">
                    <h5>E-mail:</h5>
                    <p>biblioteka@email.com</p>
                </div>
                <div class="col-md-3">
                    <h5>Adres:</h5>
                    <p>Ul. Ulica 123, 00-000 Miasto</p>
                </div>
                <div class="col-md-3">
                    <h5>Godziny otwarcia:</h5>
                    <p>Poniedziałek-Piątek: 9:00-18:00</p>
                    <p>Sobota-Niedziela: Zamknięte</p>
                </div>
            </div>
        </div>
    </footer>
    
    
</body>
</HTML>