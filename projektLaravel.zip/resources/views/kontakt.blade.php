<HTML>
    @include('shared.head', ['pageTitle' => 'Biblioteka | Kontakt'])

    <body>
        @include('shared.navbar', [
            'links' => [
                'first' => ['header' => 'Start', 'href' => '#start'],
                'second' => ['header' => 'Lista książek', 'href' => route('ksiazki')],
                'third' => ['header' => 'O Nas', 'href' =>route('info') ],
            ]
        ])



    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-9 mx-auto" style="margin: 50px 0 50px 0;">
                <h1 class="text-center">Kontakt</h1>

                <hr>

                <h5 id="nazwa">Biblioteka nazwa im. Łukasza Garbacika w Miasto</h5>
                <p>Ul. Ulica 123</p><p>
                    00-000 Miasto</p><p>
                    Tel.: (+48) 123 456 789</p><p>
                    e-mail: biblioteka@email.pl</p><p>
                    e-mail Inspektora Ochrony Danych:  inspektorDanych@email.pl</p>

                <hr>

                <h5 id="linki">Przydatne linki</h5>
                <p>Gmina Miasta <a href="">www.miasto.pl</a></p>
                <p>Gminny Ośrodek Pomocy Społecznej w Miescie: <a href="">gops.miasto.pl</a></p>
                <p>Samodzielny Publiczny Gminny Zespół Opieki Zdrowotnej w Miasto: <a href="">www.zozmiasto.pl</a></p>
                <p>Parafia Miasto <a href="">parafiamiasto.pl</a></p>
            </div>
        </div>
    </div>

    @include('shared.footer')

</body>
</HTML>
