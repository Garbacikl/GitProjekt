<!DOCTYPE html>
<html lang="pl">
<head>
    @include('shared.head', ['pageTitle' => 'Biblioteka | Rezerwacja książki'])
</head>
<body>

    @include('shared.navbar', [
        'links' => []
    ])
<div class="container mt-5">
    <h2>Lista zarezerwowanyh książek</h2>

        @if(isset($borrowedBooks) && $borrowedBooks->isEmpty())
            <p>Brak zarezerwowanych książek.</p>
        @else
            <ul class="list-group mb-4">
                @foreach($borrowedBooks as $borrowedBook)
                    @php
                        $today = date('Y-m-d');
                        $isOverdue = strtotime($borrowedBook->data_oddania) > strtotime($today);
                    @endphp
                    <li class="list-group-item">
                        <div class="row">
                            <div class="col-md-6">
                                <strong>Tytuł:</strong> {{ $borrowedBook->book->tytul }}<br>
                                <strong>Autor:</strong> {{ $borrowedBook->book->nazwa_autora }}<br>
                                <strong>Data planowanego wypożyczenia:</strong> {{ $borrowedBook->data_rezerwacji }}<br>
                                <strong>Data oddania:</strong>
                                <span style="color: {{ !$isOverdue ? 'red' : 'black' }};">
                                    {{ $borrowedBook->data_oddania }}
                                </span>
                            </div>

                            <div class="col-md-6 d-flex align-items-center justify-content-end">
                                <form action="{{ route('anuluj_rezerwacje', $borrowedBook->id) }}" method="POST">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger">Anuluj Rezerwację</button>
                                </form>
                            </div>
                        </div>
                    </li>
                @endforeach
            </ul>
        @endif
</div>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-6">
                <h2>Wyszukaj po Autorze</h2>
                <form action="{{ route('books.search') }}" method="POST">
                    @csrf
                    <div class="input-group mb-3">
                        <input type="text" name="author_name" class="form-control" placeholder="Wpisz imię i nazwisko autora">
                        <button class="btn btn-primary" type="submit">Szukaj</button>
                    </div>
                </form>
            </div>
            <div class="col-md-6">
                <h2>Wyszukaj po Tytule</h2>
                <form action="{{ route('books.search') }}" method="POST">
                    @csrf
                    <div class="input-group mb-3">
                        <input type="text" name="book_title" class="form-control" placeholder="Wpisz tytuł książki">
                        <button class="btn btn-primary" type="submit">Szukaj</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="container mt-4">
        @if (isset($books))
            <h2>Wyniki wyszukiwania</h2>
            <ul class="list-group" style="margin:0 0 50px ">
                @foreach ($books as $book)
                        <li class="list-group-item">
                            <div class="row">
                                <div class="col-md-6">
                                    {{ $book->tytul }} by {{ $book->nazwa_autora }}
                                </div>
                                <div class="col-md-6">
                                    <form action="{{ route('zarezerwuj') }}" method="POST">
                                        @csrf
                                        <input type="hidden" name="id" value="{{ $book->id_ksiazki }}">
                                        <input type="date" name="data_rezerwacji" required>
                                        <input type="date" name="data_oddania" required>
                                        <button class="btn btn-primary" type="submit">Wypożycz książkę</button>
                                    </form>
                                </div>
                            </div>
                        </li>
                    @endforeach
            </ul>
        @endif
    </div>

    @include('shared.footer')

</body>
</html>


