@can('isAdmin')
<HTML>
    @include('shared.head', ['pageTitle' => 'Biblioteka | Edytacja użytkownika'])


    <body>
        @include('shared.navbar', [
            'links' => [
                'first' => ['header' => 'Start', 'href' => '#start'],
            ]
        ])

    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-9 mx-auto" style="margin: 50px 0 50px 0;">

                @if(Session::has('success'))
                <div id="successMessage" class="d-none alert alert-success mt-3" role="alert">
                    {{ Session::get('success') }}
                </div>
                @endif

                <h5 class="text-center">Login</h5>
                <div class="col-6 mx-auto">
                    <form action="{{ route('user.search.edit') }}" method="POST">
                        @csrf
                        <div class="input-group mb-3">
                            <input type="text" name="login" class="form-control" placeholder="Wpisz login czytelnika">
                            <button class="btn btn-primary" type="submit">Szukaj</button>
                        </div>
                    </form>
                </div>

                <hr>

                @if (isset($users))
                <h2>Wyniki wyszukiwania</h2>
                <ul class="list-group" style="margin:0 0 50px ">
                    <li class="list-group-item">
                        <div class="row">
                            <div class="col-md-1">
                                <strong>ID</strong>
                            </div>
                            <div class="col-md-3">
                                <strong>Login</strong>
                            </div>
                            <div class="col-md-4    ">
                                <strong>Email</strong>
                            </div>
                            <div class="col-md-2">
                                <strong>Rola</strong>
                            </div>
                        </div>
                    </li>
                    @foreach ($users as $user)
                    <li class="list-group-item">
                        <div class="row">
                            <div class="col-md-1">
                                {{ $user->id }}
                            </div>
                            <div class="col-md-3">
                                {{ $user->login }}
                            </div>
                            <div class="col-md-4">
                                {{ $user->email }}
                            </div>
                            <div class="col-md-2">
                                {{ $user->role }}
                            </div>
                            <div class="col-md-1">
                                <a href="{{ route('editUserForm', ['id' => $user->id]) }}" class="btn btn-secondary">Edytuj</a>
                            </div>
                        </div>
                    </li>
                    @endforeach
                </ul>
                @endif

                <hr>
                @if (@isset($user))

                <h2>Aktualne dane uzytkownika</h2>
                <p><strong>Login:</strong> {{ $user->login }}</p>
                <p><strong>Email:</strong> {{ $user->email }}</p>
                <p><strong>Rola:</strong>{{$user->role}}</p>
                <p><strong>Telefon:</strong>{{$user->tel}}</p>
                <p><strong>Adres:</strong>{{$user->street}}, {{$user->city}} {{$user->zipCode}}</p>
                <hr>

                <h2>Nowe dane ksiązki</h2>
                <form method="POST" action="{{ route('updateUser')}}">
                    @csrf
                    @method('PUT')
                    <input type="hidden" name="id" value="{{ $user->id }}">
                    <div class="form-group">
                        <label for="login">Nowy login:</label>
                        <input type="text" class="form-control" id="login" name="login" value="{{$user->login}}">
                    </div>

                    <div class="form-group">
                        <label for="email">Nowy email:</label>
                        <input type="text" class="form-control" id="email" name="email" value="{{$user->email}}">
                    </div>

                    <div class="form-group">
                        <label for="role">Nowa rola:</label>
                        <select class="form-control" id="role" name="role">
                            <option value="admin" {{ $user->role === 'admin' ? 'selected' : '' }}>Admin</option>
                            <option value="user" {{ $user->role === 'user' ? 'selected' : '' }}>User</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="tel">Nowy nr. telefon:</label>
                        <input type="tel" class="form-control" id="tel" name="tel" placeholder="Telefon" pattern="\d{9}" value="{{$user->tel}}">
                    </div>

                    <div class="form-group">
                        <label for="adres">Nowy adres:</label>
                        <input type="text" class="form-control" id="street" name="street" placeholder="Ulica" value="{{$user->street}}">
                        <input type="text" class="form-control" id="city" name="city" placeholder="Miasto" value="{{$user->city}}">
                        <input type="text" class="form-control" id="zip_code" name="zip_code" placeholder="zipCode" value="{{$user->zipCode}}">
                    </div>

                    <button type="submit" class="btn btn-primary">Zapisz zmiany</button>
                </form>
                <form method="POST" action="{{ route('deleteUser', ['id' => $user->id]) }}">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger">Usuń czytelnika</button>
                </form>
                @endif
            </div>
        </div>
    </div>

    @include('shared.footer')

</body>
</HTML>
@endcan

